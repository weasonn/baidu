(function () {
    'use strict';
    var n = 0;
    var int = self.setInterval(function () {
        if (document.title == "百度一下") {
            var newslist = document.getElementsByClassName("blank-frame");
            if (newslist[0] != null) {
                newslist[0].parentNode.removeChild(newslist[0]);
                if (document.getElementById("foot").firstChild.nodeName == "DIV") {
                    document.getElementById("foot").firstChild.remove();}}
            document.getElementById("navs").remove();
            document.getElementById("logo").style.paddingTop = "150px";
            document.getElementById("ns-square-point").style.display = "none";
			document.getElementById("ts-image-uploader-icon").style.display = "none";
            window.addEventListener("resize", function () {
                document.getElementById("header").style.height = document.documentElement.clientHeight - document.getElementById("bottom").clientHeight - 10 + "px";
            }, false);
            window.dispatchEvent(new Event('resize'));
            window.clearInterval(int);
        } else {
            if (n >= 200) window.clearInterval(int);
            if (document.getElementById("s_content_2")) {
                document.getElementById("s_content_2").remove();
            }
            document.getElementById("s_menu_mine").click();
            if (document.getElementById("s_content_100")) {
                document.getElementById('s_menus_wrapper').innerHTML = '<span id="s_menu_mine" class="s-menu-item current" data-id="100">我的关注<span class="s-menu-item-underline"></span></span>';
                window.clearInterval(int);}n++;}}, 100);})();